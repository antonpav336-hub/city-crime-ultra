import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { clone as cloneSkeleton } from 'three/addons/utils/SkeletonUtils.js';

// Optional local GLB assets. Procedural geometry remains as a safe fallback.
const loader = new GLTFLoader();
const cache = new Map();
const animatedCache = new Map();

function prepareModel(root) {
  root.traverse((node) => {
    if (!node.isMesh) return;
    node.castShadow = true;
    node.receiveShadow = true;
    if (node.material) {
      const materials = Array.isArray(node.material) ? node.material : [node.material];
      for (const material of materials) {
        material.side = THREE.FrontSide;
        if ('envMapIntensity' in material) material.envMapIntensity = 0.8;
      }
    }
  });
  return root;
}

function fetchGLTF(url) {
  if (!animatedCache.has(url)) {
    animatedCache.set(url, new Promise((resolve, reject) => {
      loader.load(url, resolve, undefined, reject);
    }));
  }
  return animatedCache.get(url);
}

export function loadGameAsset(url, { scale = 1, position = [0, 0, 0], rotationY = 0 } = {}) {
  if (cache.has(url)) {
    const copy = cache.get(url).clone(true);
    copy.scale.setScalar(scale);
    copy.position.set(...position);
    copy.rotation.y = rotationY;
    return Promise.resolve(copy);
  }
  return fetchGLTF(url).then((gltf) => {
    const root = prepareModel(gltf.scene.clone(true));
    root.scale.setScalar(scale);
    root.position.set(...position);
    root.rotation.y = rotationY;
    cache.set(url, gltf.scene);
    return root;
  });
}

export async function addGameAsset(parent, url, options = {}) {
  try {
    const model = await loadGameAsset(url, options);
    parent.add(model);
    return model;
  } catch (error) {
    console.warn(`[asset] Could not load ${url}; procedural fallback remains active.`, error);
    return null;
  }
}

export async function addAnimatedGameAsset(parent, url, { height = 1.85, animation = 'Walk' } = {}) {
  try {
    const gltf = await fetchGLTF(url);
    const model = prepareModel(cloneSkeleton(gltf.scene));
    const bounds = new THREE.Box3().setFromObject(model);
    const size = bounds.getSize(new THREE.Vector3());
    const scale = height / Math.max(size.y, 0.001);
    model.scale.setScalar(scale);
    const fitted = new THREE.Box3().setFromObject(model);
    const center = fitted.getCenter(new THREE.Vector3());
    model.position.set(-center.x, -fitted.min.y, -center.z);
    parent.add(model);

    const clip = gltf.animations.find((item) => item.name.toLowerCase() === animation.toLowerCase())
      || gltf.animations.find((item) => item.name.toLowerCase() === 'idle')
      || gltf.animations[0];
    if (clip) {
      const mixer = new THREE.AnimationMixer(model);
      mixer.clipAction(clip).play();
      model.userData.animationMixer = mixer;
    }
    return model;
  } catch (error) {
    console.warn(`[asset] Could not load animated model ${url}; procedural character remains active.`, error);
    return null;
  }
}
