import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import './style.css';
import { saveGame, loadGame, exportSave, importSaveFile, clearSave } from './systems/save-system.js';
import { addGameAsset, addAnimatedGameAsset } from './assets/asset-loader.js';

// CITY CRIME: ULTRA — procedural, asset-free open-world prototype.
const $ = (id) => document.getElementById(id);
const clamp = THREE.MathUtils.clamp;
const lerp = THREE.MathUtils.lerp;
const rand = (a, b) => a + Math.random() * (b - a);
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const scene = new THREE.Scene();
const skyColor = new THREE.Color(0x91b7d0);
scene.background = skyColor;
scene.fog = new THREE.Fog(skyColor, 115, 440);
const camera = new THREE.PerspectiveCamera(66, innerWidth / innerHeight, 0.1, 900);
camera.position.set(0, 7, -12);

const isMobile = matchMedia('(pointer:coarse)').matches || innerWidth < 760;
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, isMobile ? 1.25 : 1.7));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;
$('game').appendChild(renderer.domElement);

const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, camera));
const bloom = new UnrealBloomPass(new THREE.Vector2(innerWidth, innerHeight), isMobile ? 0.22 : 0.42, 0.65, 0.78);
composer.addPass(bloom);

const hemi = new THREE.HemisphereLight(0xd8eaff, 0x39483c, 1.45);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffe4c2, 2.65);
sun.position.set(-90, 135, 70);
sun.castShadow = true;
sun.shadow.mapSize.set(isMobile ? 1024 : 2048, isMobile ? 1024 : 2048);
sun.shadow.camera.left = -230; sun.shadow.camera.right = 230;
sun.shadow.camera.top = 230; sun.shadow.camera.bottom = -230;
sun.shadow.camera.near = 1; sun.shadow.camera.far = 430;
sun.shadow.bias = -0.00015;
sun.target.position.set(0, 0, 0);
scene.add(sun, sun.target);

const mat = (color, roughness = 0.82, metalness = 0) => new THREE.MeshStandardMaterial({ color, roughness, metalness });
const mats = {
  grass: mat(0x526d50), asphalt: mat(0x242a31, 0.97), sidewalk: mat(0x92979a, 0.92), curb: mat(0xb3b6ad),
  line: mat(0xe7dfc8), yellowLine: mat(0xd4a83e), dark: mat(0x10171d, 0.65), metal: mat(0x59636a, 0.42, 0.72),
  glass: new THREE.MeshPhysicalMaterial({ color: 0x1b3c50, roughness: 0.12, metalness: 0.28, transmission: 0.12, transparent: true, opacity: 0.82 }),
  leaf: mat(0x315c3d), trunk: mat(0x62452e), concrete: mat(0x777d80), sand: mat(0xb3a17b)
};

const staticColliders = [];
const mapRoads = [];
const buildingMeshes = [];
const emissiveMaterials = [];
const lampMaterials = [];
const dummy = new THREE.Object3D();
function addMesh(geometry, material, parent = scene, position = null, castShadow = true, receiveShadow = true) {
  const mesh = new THREE.Mesh(geometry, material);
  if (position) mesh.position.copy(position);
  mesh.castShadow = castShadow;
  mesh.receiveShadow = receiveShadow;
  parent.add(mesh);
  return mesh;
}
function addBox(w, h, d, material, x, y, z, parent = scene, shadow = true) {
  return addMesh(new THREE.BoxGeometry(w, h, d), material, parent, new THREE.Vector3(x, y, z), shadow, true);
}
function addGround(w, d, material, x = 0, z = 0) {
  const m = addMesh(new THREE.PlaneGeometry(w, d), material, scene, new THREE.Vector3(x, -0.06, z), false, true);
  m.rotation.x = -Math.PI / 2;
  return m;
}

// Procedural textures: every texture is generated locally, no remote assets required.
function makeAsphaltTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 512;
  const ctx = c.getContext('2d'); ctx.fillStyle = '#292e33'; ctx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 24000; i++) {
    const v = Math.floor(rand(30, 95)); ctx.fillStyle = `rgba(${v},${v},${v},${rand(.025,.13)})`;
    const s = rand(.4, 2.4); ctx.fillRect(Math.random() * 512, Math.random() * 512, s, s);
  }
  for (let i = 0; i < 26; i++) { ctx.strokeStyle = `rgba(8,12,16,${rand(.04,.12)})`; ctx.lineWidth = rand(1, 3); ctx.beginPath(); const x = rand(0,512), y = rand(0,512); ctx.moveTo(x,y); ctx.lineTo(x+rand(-90,90),y+rand(-90,90)); ctx.stroke(); }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(5, 22); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = renderer.capabilities.getMaxAnisotropy(); return t;
}
function makeFacadeTexture(base, seed) {
  const c = document.createElement('canvas'); c.width = 512; c.height = 512;
  const ctx = c.getContext('2d'); ctx.fillStyle = base; ctx.fillRect(0,0,512,512);
  const cols = 7, rows = 10, cw = 512 / cols, rh = 512 / rows;
  for (let r = 0; r < rows; r++) for (let col = 0; col < cols; col++) {
    const x = col*cw + 10, y = r*rh + 9, w = cw-20, h = rh-18;
    ctx.fillStyle = 'rgba(13,25,34,.92)'; ctx.fillRect(x-3,y-3,w+6,h+6);
    const lit = Math.sin((r+1)*12.9898 + (col+1)*78.233 + seed*33.17) > -.05;
    ctx.fillStyle = lit ? pick(['#f5cf83','#e8b96a','#8e9c9e']) : pick(['#193342','#243d49','#101f2a']);
    ctx.fillRect(x,y,w,h);
    ctx.fillStyle = 'rgba(255,255,255,.15)'; ctx.fillRect(x,y,w,2);
    if (lit && Math.random() > .45) { ctx.fillStyle = 'rgba(27,45,46,.5)'; ctx.fillRect(x+4,y+4,w*.42,h*.7); }
  }
  ctx.fillStyle = 'rgba(8,13,18,.18)'; for(let y=0;y<512;y+=rh)ctx.fillRect(0,y,512,3);
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = renderer.capabilities.getMaxAnisotropy(); return tex;
}
const asphaltTexture = makeAsphaltTexture();
const asphaltMaterial = new THREE.MeshStandardMaterial({ map: asphaltTexture, roughness: 0.98 });

// World floor and waterfront.
addGround(520, 520, mats.grass);
const waterMat = new THREE.MeshPhysicalMaterial({ color: 0x1b6685, roughness: 0.17, metalness: 0.18, clearcoat: 1, clearcoatRoughness: 0.08 });
const water = addMesh(new THREE.PlaneGeometry(125, 520, 1, 1), waterMat, scene, new THREE.Vector3(257, -0.22, 0), false, false);
water.rotation.x = -Math.PI / 2;
addGround(30, 520, mats.sand, 190, 0);
// Pier and marina details.
for (let i=0;i<7;i++) {
  addBox(3,.6,22,mat(0x6d5b45),207,0.12,-110+i*38);
  for(let z=-119+i*38;z<-91+i*38;z+=18) for(const x of [206,208]) addMesh(new THREE.CylinderGeometry(.22,.28,3,7),mats.trunk,scene,new THREE.Vector3(x,-1.1,z),true,true);
}

// Street grid, with lane markings and crosswalks.
const roadCenters = [-160, -80, 0, 80, 160];
function road(axis, center) {
  const w = 20, len = 420;
  if (axis === 'x') {
    const m = addGround(len, w, asphaltMaterial, 0, center); mapRoads.push({x:0,z:center,w:len,d:w});
    for (let x=-205; x<205; x+=16) {
      addBox(7,.018,.16,mats.line,x,.015,center-5.4,scene,false);
      addBox(7,.018,.16,mats.line,x,.015,center+5.4,scene,false);
    }
    addBox(len,.022,.2,mats.yellowLine,0,.02,center-.12,scene,false);
    addBox(len,.022,.2,mats.yellowLine,0,.02,center+.12,scene,false);
  } else {
    addGround(w, len, asphaltMaterial, center, 0); mapRoads.push({x:center,z:0,w,d:len});
    for (let z=-205; z<205; z+=16) {
      addBox(.16,.018,7,mats.line,center-5.4,.015,z,scene,false);
      addBox(.16,.018,7,mats.line,center+5.4,.015,z,scene,false);
    }
    addBox(.2,.022,len,mats.yellowLine,center-.12,.02,0,scene,false);
    addBox(.2,.022,len,mats.yellowLine,center+.12,.02,0,scene,false);
  }
}
roadCenters.forEach(v => { road('x',v); road('z',v); });
// Sidewalks, curbs, crosswalks, parking bays.
for (const v of roadCenters) {
  addGround(420,3.6,mats.sidewalk,0,v-12.1); addGround(420,3.6,mats.sidewalk,0,v+12.1);
  addGround(3.6,420,mats.sidewalk,v-12.1,0); addGround(3.6,420,mats.sidewalk,v+12.1,0);
  addBox(420,.16,.32,mats.curb,0,.05,v-10.1,scene,false); addBox(420,.16,.32,mats.curb,0,.05,v+10.1,scene,false);
  addBox(.32,.16,420,mats.curb,v-10.1,.05,0,scene,false); addBox(.32,.16,420,mats.curb,v+10.1,.05,0,scene,false);
  for (const cross of roadCenters) {
    for (let i=-4;i<=4;i++) {
      addBox(1.3,.025,5.8,mats.line,cross+i*1.9,.025,v-7,scene,false);
      addBox(5.8,.025,1.3,mats.line,v-7,.025,cross+i*1.9,scene,false);
    }
  }
}

// Buildings: varied silhouettes, facade atlases, rooftop machinery and collision volumes.
const palettes = [0x9c9d98,0xb7a58e,0x697b80,0x879294,0x6f777c,0xc0b6a1,0x536770,0x9a8f82];
function createBuilding(x,z,w,d,h,style=0) {
  const baseColor = pick(palettes);
  const tex = makeFacadeTexture('#'+baseColor.toString(16).padStart(6,'0'), buildingsMeshes.length+Math.random());
  const emissive = new THREE.Color(0x60401e);
  const material = new THREE.MeshStandardMaterial({ map:tex, roughness:.82, metalness:.08, emissive, emissiveMap:tex, emissiveIntensity:.07 });
  emissiveMaterials.push(material);
  const body = addBox(w,h,d,material,x,h/2,z);
  buildingMeshes.push(body);
  staticColliders.push({minX:x-w/2,maxX:x+w/2,minZ:z-d/2,maxZ:z+d/2,top:h});
  const trim = mat(style%2?0x303c43:0xd0c8b7,.7,.12);
  addBox(w+0.65,.45,d+0.65,trim,x,h+.2,z);
  if(h>24){addBox(w*.55,1.8,d*.5,mats.dark,x,h+1.25,z);addBox(w*.22,.6,d*.22,mats.metal,x+w*.18,h+2.45,z-d*.1);}
  // Vertical corner bands and shallow street-level store fronts.
  if(style%3===0){
    for(const sx of [-1,1]) addBox(.32,h,.34,trim,x+sx*(w/2-.16),h/2,z+d/2+.08);
  }
  if(h<18){
    const signMat = new THREE.MeshStandardMaterial({color:pick([0xd35b43,0x3f9a9a,0xd2a64f,0x547baf]),emissive:0x392018,emissiveIntensity:.45});
    addBox(w*.58,.75,.18,signMat,x,h*.42,z+d/2+.16);
    addBox(w*.72,.25,.45,mat(0x394149),x,h*.22,z+d/2+.15);
  }
  // A few AC units on selected walls.
  if(style%4===0){for(let i=0;i<2;i++)addBox(1.1,.65,.5,mats.metal,x-w*.25+i*w*.5,Math.min(h-2,4.2+i*3),z+d/2+.35);}
}
let buildingsMeshes = [];
let styleIndex = 0;
for (let bx=-120;bx<=120;bx+=80) for(let bz=-120;bz<=120;bz+=80) {
  const district = Math.abs(bx)+Math.abs(bz);
  const count = district<90 ? 4 : 3;
  const lotOffsets = [[-16,-16],[16,-16],[-16,16],[16,16]];
  for(let i=0;i<count;i++){
    const [ox,oz]=lotOffsets[i];
    const x=bx+ox+rand(-1.8,1.8), z=bz+oz+rand(-1.8,1.8);
    const w=rand(12,16), d=rand(12,16);
    let h= district<90 ? rand(24,58) : district<190 ? rand(12,34) : rand(8,22);
    if(Math.random()<.17)h*=1.55;
    createBuilding(x,z,w,d,h,styleIndex++);
  }
}

// Streetscape: trees, planters, benches, lamps, bollards and signs.
const lampBulbs=[];
function createTree(x,z,scale=1){
  const g=new THREE.Group(); scene.add(g); g.position.set(x,0,z); g.scale.setScalar(scale);
  const trunk=addMesh(new THREE.CylinderGeometry(.22,.36,3.5,8),mats.trunk,g,new THREE.Vector3(0,1.75,0));
  const crownMat=mat(pick([0x28573b,0x376b43,0x416c48,0x2f6047]),.95);
  for(let i=0;i<3;i++){const s=rand(1.2,1.8);const crown=addMesh(new THREE.IcosahedronGeometry(s,1),crownMat,g,new THREE.Vector3(rand(-.65,.65),3.2+rand(-.2,1.1),rand(-.65,.65)));crown.castShadow=true;}
}
function createLamp(x,z,rot=0){
  const g=new THREE.Group();scene.add(g);g.position.set(x,0,z);g.rotation.y=rot;
  addMesh(new THREE.CylinderGeometry(.09,.14,6.8,8),mats.dark,g,new THREE.Vector3(0,3.4,0));
  addMesh(new THREE.BoxGeometry(.12,.12,2.2),mats.dark,g,new THREE.Vector3(0,6.55,.85));
  const bulbMat=new THREE.MeshStandardMaterial({color:0xffdca2,emissive:0xffbb66,emissiveIntensity:.1});lampMaterials.push(bulbMat);
  addMesh(new THREE.BoxGeometry(.42,.18,.62),bulbMat,g,new THREE.Vector3(0,6.45,1.75),false,false);lampBulbs.push(bulbMat);
}
function createBench(x,z,rot=0){const g=new THREE.Group();scene.add(g);g.position.set(x,0,z);g.rotation.y=rot;const wood=mat(0x6e563d);addBox(2,.18,.55,wood,0,.65,0,g);for(const x0 of [-.72,.72])addBox(.16,.7,.5,mats.dark,x0,.35,0,g);addBox(2,.65,.14,wood,0,1.05,-.23,g);}
for(let x=-185;x<=185;x+=36){for(const z of [-173,-93,-13,67,147]){if(Math.random()>.32)createTree(x+rand(-2,2),z+rand(-2,2),rand(.8,1.15));}}
for(let z=-185;z<=185;z+=36){for(const x of [-173,-93,-13,67,147]){if(Math.random()>.38)createTree(x+rand(-2,2),z+rand(-2,2),rand(.75,1.1));}}
for(const v of roadCenters){for(let p=-180;p<=180;p+=90){createLamp(p,v-14,0);createLamp(v+14,p,Math.PI/2);if(p%120===0)createBench(p+2,v+14,Math.PI/2);}}

// Skyline, stars and sun disc.
const skylineMat=mat(0x45525b);
for(let i=0;i<54;i++){
  const a=rand(0,Math.PI*2),r=rand(250,340),h=rand(18,80),w=rand(8,22),d=rand(8,22);
  const b=addBox(w,h,d,skylineMat,Math.cos(a)*r,h/2,Math.sin(a)*r,scene,false);b.castShadow=false;
}
const starGeo=new THREE.BufferGeometry(), starPositions=[];
for(let i=0;i<750;i++){const a=Math.random()*Math.PI*2, y=rand(55,185),r=rand(270,380);starPositions.push(Math.cos(a)*r,y,Math.sin(a)*r);}
starGeo.setAttribute('position',new THREE.Float32BufferAttribute(starPositions,3));
const stars=new THREE.Points(starGeo,new THREE.PointsMaterial({color:0xc8ddff,size:.95,transparent:true,opacity:0,depthWrite:false}));scene.add(stars);
const sunDisc=addMesh(new THREE.SphereGeometry(9,20,16),new THREE.MeshBasicMaterial({color:0xffd49a}),scene,new THREE.Vector3(-120,150,-190),false,false);

// Player character: layered body with animated limbs and clothing details.
const player = new THREE.Group(); scene.add(player); player.position.set(-10,0,-3);
const skin = mat(0xb98062,.78); const jacket = new THREE.MeshStandardMaterial({color:0x283d4a,roughness:.76});
const pants = mat(0x202a32); const shoe = mat(0x11171c,.7);
const torso = addMesh(new THREE.CapsuleGeometry(.39,.72,5,10),jacket,player,new THREE.Vector3(0,1.15,0));
const head = addMesh(new THREE.SphereGeometry(.27,16,12),skin,player,new THREE.Vector3(0,1.96,.02));
const hair = addMesh(new THREE.SphereGeometry(.275,14,10,0,Math.PI*2,0,Math.PI*.48),mat(0x201d1a),player,new THREE.Vector3(0,2.04,-.015));
const armL=new THREE.Group(),armR=new THREE.Group(),legL=new THREE.Group(),legR=new THREE.Group();
player.add(armL,armR,legL,legR);armL.position.set(-.48,1.48,0);armR.position.set(.48,1.48,0);legL.position.set(-.2,.72,0);legR.position.set(.2,.72,0);
for(const [g,side] of [[armL,-1],[armR,1]]){addMesh(new THREE.CapsuleGeometry(.13,.48,4,8),jacket,g,new THREE.Vector3(side*.02,-.32,0));addMesh(new THREE.SphereGeometry(.135,8,8),skin,g,new THREE.Vector3(0,-.67,.02));}
for(const [g] of [[legL],[legR]]){addMesh(new THREE.CapsuleGeometry(.17,.55,4,8),pants,g,new THREE.Vector3(0,-.28,0));addMesh(new THREE.BoxGeometry(.29,.16,.42),shoe,g,new THREE.Vector3(0,-.62,.09));}
const playerShadow = addMesh(new THREE.CircleGeometry(.62,24),new THREE.MeshBasicMaterial({color:0x081014,transparent:true,opacity:.28,depthWrite:false}),scene,new THREE.Vector3(-10,.012,-3),false,false);playerShadow.rotation.x=-Math.PI/2;
addAnimatedGameAsset(player,'/assets/characters/casual-walker.glb',{height:1.85,animation:'Idle'}).then(model=>{if(model){for(const child of [...player.children])if(child!==model)child.visible=false;player.userData.animationMixer=model.userData.animationMixer;console.info('[asset] Player character model loaded.');}});

// Vehicle factory: multi-part body, glass, wheel assemblies, lights and metallic trim.
const cars=[];
const vehiclePaint=(color)=>new THREE.MeshPhysicalMaterial({color,roughness:.28,metalness:.55,clearcoat:1,clearcoatRoughness:.18});
const rubber=mat(0x101317,.96), chrome=mat(0x9ba6aa,.24,.88);
function createCar(x,z,color=0x3e7894,type='sedan',isTraffic=false){
  const g=new THREE.Group();scene.add(g);g.position.set(x,0,z);
  const isTruck=type==='truck', isSUV=type==='suv';
  const length=isTruck?5.8:isSUV?4.6:4.25, width=isTruck?2.25:2.02;
  const paint=vehiclePaint(color), glass=new THREE.MeshPhysicalMaterial({color:0x183344,roughness:.1,metalness:.28,transparent:true,opacity:.83});
  addBox(width,.62,length,paint,0,.72,0,g);
  addBox(width*.91,.16,length*.58,mat(0x20272b,.48,.28),0,.43,-.03,g);
  const cabinZ=isTruck?-.7:-.28, cabinLen=isTruck?2.15:2.25;
  addBox(width*.84,isTruck?1.05:1.0,cabinLen,paint,0,1.39,cabinZ,g);
  // Windscreen and side windows, angled slightly for a less toy-like silhouette.
  addBox(width*.78,.74,.08,glass,0,1.47,cabinZ+cabinLen/2+.035,g).rotation.x=-.14;
  addBox(width*.78,.7,.08,glass,0,1.47,cabinZ-cabinLen/2-.035,g).rotation.x=.12;
  for(const side of [-1,1]){
    addBox(.07,.68,cabinLen*.8,glass,side*width*.43,1.48,cabinZ,g);
    addMesh(new THREE.BoxGeometry(.12,.18,.34),chrome,g,new THREE.Vector3(side*width*.54,1.28,.55));
    addBox(.06,.48,length*.62,mat(0x8b969d,.34,.7),side*width*.5,.72,0,g);
  }
  // Hood and trunk definition.
  addBox(width*.92,.12,length*.25,paint,0,1.0,length*.34,g);
  if(!isTruck)addBox(width*.9,.1,length*.2,paint,0,1.02,-length*.36,g);
  const wheels=[];
  for(const wx of [-width*.51,width*.51])for(const wz of [-length*.32,length*.32]){
    const pivot=new THREE.Group();pivot.position.set(wx,.42,wz);g.add(pivot);
    const tire=addMesh(new THREE.CylinderGeometry(.4,.4,.27,18,1),rubber,pivot,new THREE.Vector3(0,0,0));tire.rotation.z=Math.PI/2;
    const rim=addMesh(new THREE.CylinderGeometry(.22,.22,.285,12),chrome,pivot,new THREE.Vector3(0,0,0));rim.rotation.z=Math.PI/2;
    wheels.push({pivot,tire,front:wz>0});
  }
  const headMat=new THREE.MeshStandardMaterial({color:0xfff1ca,emissive:0xffdca2,emissiveIntensity:.25});
  const tailMat=new THREE.MeshStandardMaterial({color:0x9c221d,emissive:0xff180d,emissiveIntensity:.28});
  for(const side of [-1,1]){
    addBox(.42,.2,.08,headMat,side*width*.34,.87,length*.5,g);
    addBox(.42,.2,.08,tailMat,side*width*.34,.85,-length*.5,g);
  }
  // Grille, bumpers and number plate.
  addBox(width*.52,.23,.09,mats.dark,0,.61,length*.51,g);
  addBox(width*.76,.13,.12,chrome,0,.43,length*.53,g);
  addBox(width*.72,.12,.12,chrome,0,.43,-length*.53,g);
  if(isTruck){addBox(width*.95,1.1,length*.36,mat(0x69747b),0,1.52,-length*.27,g);}
  const car={g,type,color,speed:0,yaw:0,velocity:new THREE.Vector3(),wheels,hp:100,owned:false,isTraffic,ai:null,length,width,paint,headMat,tailMat,damageFlash:0};
  cars.push(car);
  const modelPath=type==='suv'?'/assets/vehicles/suv.glb':type==='truck'?'/assets/vehicles/box-truck.glb':'/assets/vehicles/sedan.glb';
  (async()=>{
    const model=await addGameAsset(g,modelPath);
    if(!model)return;
    const bounds=new THREE.Box3().setFromObject(model);
    const size=bounds.getSize(new THREE.Vector3());
    model.scale.multiplyScalar(length/Math.max(size.x,size.z,.001));
    const fitted=new THREE.Box3().setFromObject(model);
    const center=fitted.getCenter(new THREE.Vector3());
    model.position.x-=center.x;model.position.z-=center.z;model.position.y-=fitted.min.y;
    for(const child of [...g.children]) if(child!==model) child.visible=false;
    car.externalModel=model;
  })();
  return car;
}
const starterCar=createCar(-10,2,0x226b85,'sedan');
createCar(12,-7,0xb7a35f,'suv');
createCar(-38,42,0x9d493b,'sedan');
createCar(78,-118,0x526c5e,'truck');
createCar(-118,78,0x414c70,'suv');
// Traffic follows lanes around the grid and loops at map edges.
const traffic=[];
for(let i=0;i<12;i++){
  const axis=Math.random()<.5?'x':'z', road=pick(roadCenters), sign=Math.random()<.5?1:-1, lane=sign>0?-4.2:4.2;
  const x=axis==='x'?rand(-195,195):road+lane, z=axis==='z'?rand(-195,195):road+lane;
  const c=createCar(x,z,pick([0x9c5546,0x416f87,0xb7b19f,0x4c555b,0x42604e,0x7d536b]),pick(['sedan','sedan','suv']),true);
  c.ai={axis,road,sign,lane};c.speed=rand(7,13);c.yaw=axis==='x'?(sign>0?Math.PI/2:-Math.PI/2):(sign>0?0:Math.PI);c.g.rotation.y=c.yaw;traffic.push(c);
}

// Pedestrians and police officers.
const npcs=[];const policeUnits=[];
const npcColors=[0x6b7770,0x435b6a,0x8a6654,0x6c5068,0x9a886c,0x394c45,0x6d6e78];
function createNPC(x,z,police=false,hostile=false){
  const g=new THREE.Group();scene.add(g);const shirt=mat(police?0x1b3553:hostile?0x6c332e:pick(npcColors));
  const torsoMesh=addMesh(new THREE.CapsuleGeometry(.3,.55,4,7),shirt,g,new THREE.Vector3(0,1.04,0));
  const h=addMesh(new THREE.SphereGeometry(.205,10,8),skin,g,new THREE.Vector3(0,1.72,.02));
  const l=new THREE.Group(),r=new THREE.Group();g.add(l,r);l.position.set(-.32,1.35,0);r.position.set(.32,1.35,0);
  addMesh(new THREE.CapsuleGeometry(.1,.38,3,6),shirt,l,new THREE.Vector3(0,-.22,0));addMesh(new THREE.CapsuleGeometry(.1,.38,3,6),shirt,r,new THREE.Vector3(0,-.22,0));
  if(police){addMesh(new THREE.BoxGeometry(.42,.16,.4),mats.dark,g,new THREE.Vector3(0,1.91,0));addMesh(new THREE.BoxGeometry(.11,.12,.03),mat(0xe1bb5a),g,new THREE.Vector3(.16,1.13,.28));}
  const n={g,hp:100,police,hostile,dir:rand(0,Math.PI*2),speed:rand(.6,1.2),alert:false,panic:0,phase:rand(0,7),arms:[l,r],legs:[],attackCooldown:0};
  npcs.push(n);if(police)policeUnits.push(n);
  addAnimatedGameAsset(g,'/assets/characters/casual-walker.glb',{height:1.78,animation:'Walk'}).then(model=>{
    if(model){for(const child of [...g.children])if(child!==model)child.visible=false;n.animationMixer=model.userData.animationMixer;}
  });
  return n;
}
for(let i=0;i<32;i++){
  let x=rand(-180,180),z=rand(-180,180);
  if(Math.abs(x%80)<15||Math.abs(z%80)<15){i--;continue;}
  createNPC(x,z,false,Math.random()<.08);
}
let lastKnown=new THREE.Vector3(), wanted=0, wantedTimer=0;
function addWanted(amount=1){
  const next=Math.min(5,wanted+amount);if(next===wanted)return;wanted=next;wantedTimer=0;lastKnown.copy(player.position);
  while(policeUnits.length<Math.min(2+wanted,6)){
    const a=rand(0,Math.PI*2),r=rand(24,38);createNPC(player.position.x+Math.cos(a)*r,player.position.z+Math.sin(a)*r,true,false);
  }
  updateWantedUI();toast('ПОЛИЦИЯ: УРОВЕНЬ РОЗЫСКА ПОВЫШЕН');
}
function clearWanted(){wanted=0;wantedTimer=0;for(const p of [...policeUnits]){scene.remove(p.g);npcs.splice(npcs.indexOf(p),1);}policeUnits.length=0;updateWantedUI();toast('Полиция потеряла твой след');}
function updateWantedUI(){$('wanted').textContent='★'.repeat(wanted)+'☆'.repeat(5-wanted);}

// Mission chain.
const missionTargets=[
  {x:42,z:-38,title:'ПЕРВЫЙ КОНТАКТ',desc:'Доберись до золотой метки у автомастерской.',reward:650},
  {x:-118,z:118,title:'ГОРОДСКОЙ КУРЬЕР',desc:'Пересечь город и доставить посылку в доки.',reward:950},
  {x:118,z:-118,title:'ПОСЛЕДНИЙ ЗВОНОК',desc:'Добраться до смотровой площадки на холме.',reward:1450},
  {x:158,z:38,title:'НОЧНОЙ МАРШРУТ',desc:'Найти прибрежную парковку и забрать оплату.',reward:1850}
];
let missionIndex=0;
const markerGroup=new THREE.Group();scene.add(markerGroup);
const markerRing=addMesh(new THREE.TorusGeometry(2.5,.16,10,36),new THREE.MeshBasicMaterial({color:0xffca62}),markerGroup,new THREE.Vector3(0,.18,0),false,false);markerRing.rotation.x=Math.PI/2;
const markerBeam=addMesh(new THREE.CylinderGeometry(.08,.9,7,18,1,true),new THREE.MeshBasicMaterial({color:0xffbd55,transparent:true,opacity:.12,depthWrite:false}),markerGroup,new THREE.Vector3(0,3.7,0),false,false);
const markerCore=addMesh(new THREE.CylinderGeometry(.035,.035,3.2,8),new THREE.MeshBasicMaterial({color:0xffd37c,transparent:true,opacity:.55}),markerGroup,new THREE.Vector3(0,3.9,0),false,false);
function setMission(){const m=missionTargets[missionIndex%missionTargets.length];markerGroup.position.set(m.x,0,m.z);$('mission-title').textContent=m.title;$('mission-desc').textContent=m.desc;$('mission-progress').style.width='0%';}
setMission();

// Input state and player statistics.
const keys=Object.create(null);let yaw=0,pitch=-.14,velocity=new THREE.Vector3(),health=100,armor=25,stamina=100,cash=2500;
let inCar=null,dead=false,started=false,paused=true,worldTime=15.2,toastTimer=0,shake=0,lastAttack=0;
const joystick={x:0,y:0,active:false};let touchLook=null;
function toast(message){$('toast').textContent=message;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),2500);}
function updateHUD(){
  $('cash').textContent='$ '+cash.toLocaleString('en-US');$('health-value').textContent=Math.ceil(health);$('armor-value').textContent=Math.ceil(armor);$('stamina-value').textContent=Math.ceil(stamina);
  $('health-bar').style.width=health+'%';$('armor-bar').style.width=armor+'%';$('stamina-bar').style.width=stamina+'%';
}
function drawMap(canvas,big=false){
  if(!canvas)return;const ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);
  ctx.fillStyle='#182c30';ctx.fillRect(0,0,w,h);const scale=big?1.22:.64,cx=player.position.x,cz=player.position.z;
  ctx.save();ctx.translate(w/2,h/2);ctx.scale(scale,scale);ctx.translate(-cx,-cz);
  ctx.fillStyle='#38434a';for(const r of mapRoads)ctx.fillRect(r.x-r.w/2,r.z-r.d/2,r.w,r.d);
  ctx.strokeStyle='#8d999b';ctx.lineWidth=big?1.1:.65;for(const r of mapRoads)ctx.strokeRect(r.x-r.w/2,r.z-r.d/2,r.w,r.d);
  ctx.fillStyle='#667a69';for(const b of staticColliders)ctx.fillRect(b.minX,b.minZ,b.maxX-b.minX,b.maxZ-b.minZ);
  const m=missionTargets[missionIndex%missionTargets.length];ctx.fillStyle='#ffca62';ctx.beginPath();ctx.arc(m.x,m.z,3.5,0,Math.PI*2);ctx.fill();
  for(const c of cars){ctx.fillStyle=c===inCar?'#f4d36d':'#b0bdc4';ctx.fillRect(c.g.position.x-1.4,c.g.position.z-2,2.8,4);}
  ctx.fillStyle='#57c8f1';ctx.beginPath();ctx.arc(player.position.x,player.position.z,3.2,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle='#9deaff';ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(player.position.x,player.position.z);ctx.lineTo(player.position.x+Math.sin(yaw)*9,player.position.z+Math.cos(yaw)*9);ctx.stroke();
  ctx.restore();
}

function resolveCircleRect(position,radius,rect){
  const closestX=clamp(position.x,rect.minX,rect.maxX),closestZ=clamp(position.z,rect.minZ,rect.maxZ);
  let dx=position.x-closestX,dz=position.z-closestZ,distSq=dx*dx+dz*dz;
  if(distSq<radius*radius){
    if(distSq<.0001){const left=Math.abs(position.x-rect.minX),right=Math.abs(rect.maxX-position.x),top=Math.abs(position.z-rect.minZ),bottom=Math.abs(rect.maxZ-position.z),m=Math.min(left,right,top,bottom);if(m===left)dx=-1;else if(m===right)dx=1;else if(m===top)dz=-1;else dz=1;distSq=1;}
    const dist=Math.sqrt(distSq),push=(radius-dist)+.015;position.x+=(dx/dist)*push;position.z+=(dz/dist)*push;return true;
  }return false;
}
function collideWorld(pos,radius){let hit=false;for(const b of staticColliders)if(resolveCircleRect(pos,radius,b))hit=true;pos.x=clamp(pos.x,-204,204);pos.z=clamp(pos.z,-204,204);return hit;}
function nearestCar(){let best=null,distance=7;for(const c of cars){if(c.isTraffic)continue;const d=c.g.position.distanceTo(player.position);if(d<distance){best=c;distance=d;}}return best;}
function toggleCar(){
  if(inCar){const exit=new THREE.Vector3(1.8,0,-.3).applyAxisAngle(new THREE.Vector3(0,1,0),inCar.yaw);player.position.copy(inCar.g.position).add(exit);player.position.y=0;player.visible=true;inCar=null;toast('Ты вышел из автомобиля');return;}
  const c=nearestCar();if(c){inCar=c;player.visible=false;c.owned=true;toast('Автомобиль открыт — поехали!');if(c.speed>3)c.speed=0;}
}
function damage(amount){if(armor>0){const absorbed=Math.min(armor,amount*.62);armor-=absorbed;amount-=absorbed;}health=Math.max(0,health-amount);updateHUD();if(health<=0){dead=true;paused=true;$('death-screen').classList.remove('hidden');document.exitPointerLock?.();}}
function respawn(){health=100;armor=25;stamina=100;dead=false;player.visible=true;player.position.set(-10,0,-3);velocity.set(0,0,0);if(inCar){inCar.speed=0;inCar=null;}clearWanted();$('death-screen').classList.add('hidden');paused=false;renderer.domElement.requestPointerLock?.();}

function attack(){
  if(inCar||performance.now()-lastAttack<520)return;lastAttack=performance.now();let target=null,best=3.0;const forward=new THREE.Vector3(Math.sin(yaw),0,Math.cos(yaw));
  for(const n of npcs){if(n.police&&n.hp<=0)continue;const delta=n.g.position.clone().sub(player.position);const d=delta.length();if(d<best&&delta.normalize().dot(forward)>.05){target=n;best=d;}}
  if(target){target.hp-=48;target.alert=true;target.panic=6;target.g.position.addScaledVector(forward,1.1);addWanted(1);toast('УДАР ПОПАЛ В ЦЕЛЬ');if(target.hp<=0){scene.remove(target.g);npcs.splice(npcs.indexOf(target),1);cash+=100;updateHUD();}}
  else toast('УДАР');
}

// Lightweight particle pool for dust and tire smoke.
const particles=[];
function spawnSmoke(position,amount=1){
  for(let i=0;i<amount;i++){
    const m=addMesh(new THREE.SphereGeometry(rand(.12,.3),7,6),new THREE.MeshBasicMaterial({color:0x9ca6a8,transparent:true,opacity:.22,depthWrite:false}),scene,position.clone().add(new THREE.Vector3(rand(-.7,.7),rand(.2,.6),rand(-.7,.7))),false,false);
    particles.push({mesh:m,life:rand(.45,.9),max:.9,velocity:new THREE.Vector3(rand(-.6,.6),rand(.4,1.1),rand(-.6,.6))});
  }
}

function updatePlayer(dt){
  let ix=(keys.KeyD?1:0)-(keys.KeyA?1:0),iy=(keys.KeyW?1:0)-(keys.KeyS?1:0);
  if(joystick.active){ix=joystick.x;iy=-joystick.y;}
  const move=new THREE.Vector3(Math.sin(yaw)*iy+Math.cos(yaw)*ix,0,Math.cos(yaw)*iy-Math.sin(yaw)*ix);
  if(move.lengthSq()>1)move.normalize();
  const running=(keys.ShiftLeft||keys.ShiftRight)&&stamina>2&&move.lengthSq()>.01;
  const maxSpeed=running?10.4:6.0;stamina=clamp(stamina+(running?-24:14)*dt,0,100);
  const target=move.multiplyScalar(maxSpeed);const response=move.lengthSq()>.001?10:7;
  velocity.x=lerp(velocity.x,target.x,1-Math.exp(-response*dt));velocity.z=lerp(velocity.z,target.z,1-Math.exp(-response*dt));
  const old=player.position.clone();player.position.x+=velocity.x*dt;player.position.z+=velocity.z*dt;
  if(collideWorld(player.position,.62)){velocity.x*=.25;velocity.z*=.25;}
  const grounded=player.position.y<=.001;
  if(keys.Space&&grounded){velocity.y=7.1;}
  velocity.y-=19*dt;player.position.y=Math.max(0,player.position.y+velocity.y*dt);if(player.position.y===0)velocity.y=0;
  if(move.lengthSq()>.01){const desired=Math.atan2(velocity.x,velocity.z);let diff=Math.atan2(Math.sin(desired-player.rotation.y),Math.cos(desired-player.rotation.y));player.rotation.y+=diff*(1-Math.exp(-12*dt));}
  const stride=Math.min(1,Math.hypot(velocity.x,velocity.z)/6);const t=performance.now()*.012;
  legL.rotation.x=Math.sin(t)*stride*.75;legR.rotation.x=-Math.sin(t)*stride*.75;
  armL.rotation.x=-Math.sin(t)*stride*.62;armR.rotation.x=Math.sin(t)*stride*.62;
  torso.rotation.z=lerp(torso.rotation.z,-(keys.KeyA?-.08:keys.KeyD?.08:0),dt*5);
  playerShadow.position.set(player.position.x,.012,player.position.z);playerShadow.scale.setScalar(1+player.position.y*.15);
}

function updatePlayerCar(dt){
  if(!inCar)return;
  const c=inCar;let throttle=(keys.KeyW?1:0)-(keys.KeyS?1:0);let steer=(keys.KeyD?1:0)-(keys.KeyA?1:0);
  if(joystick.active){throttle=clamp(-joystick.y,-1,1);steer=clamp(joystick.x,-1,1);}
  const handbrake=!!keys.Space,boost=(keys.ShiftLeft||keys.ShiftRight);
  const forward=new THREE.Vector3(Math.sin(c.yaw),0,Math.cos(c.yaw));const right=new THREE.Vector3(forward.z,0,-forward.x);
  let longitudinal=c.velocity.dot(forward),lateral=c.velocity.dot(right);
  if(throttle>0)longitudinal+=throttle*(boost?30:23)*dt;
  else if(throttle<0){if(longitudinal>2)longitudinal+=throttle*38*dt;else longitudinal+=throttle*12*dt;}
  const max=boost?39:32;longitudinal=clamp(longitudinal,-11,max);
  longitudinal*=Math.exp(-(Math.abs(throttle)<.05?1.15:.18)*dt);
  lateral*=Math.exp(-(handbrake?1.15:8.5)*dt);
  const speedFactor=clamp(Math.abs(longitudinal)/4,0,1.35);
  c.yaw+=steer*speedFactor*(longitudinal>=0?1:-1)*(handbrake?2.35:1.72)*dt;
  if(Math.abs(longitudinal)<.8) c.yaw+=steer*.15*dt;
  const f=new THREE.Vector3(Math.sin(c.yaw),0,Math.cos(c.yaw)),r=new THREE.Vector3(f.z,0,-f.x);
  c.velocity.copy(f).multiplyScalar(longitudinal).addScaledVector(r,lateral);
  const before=c.g.position.clone();c.g.position.addScaledVector(c.velocity,dt);
  const hit=collideWorld(c.g.position,c.width*.68);
  // Bumper-to-bumper arcade response.
  for(const other of cars){if(other===c)continue;const dx=c.g.position.x-other.g.position.x,dz=c.g.position.z-other.g.position.z,dist=Math.hypot(dx,dz),min=(c.width+other.width)*.43;if(dist<min){const nx=dx/(dist||1),nz=dz/(dist||1),push=min-dist;c.g.position.x+=nx*push;c.g.position.z+=nz*push;c.velocity.multiplyScalar(-.24);c.hp-=Math.abs(longitudinal)*.5;shake=Math.max(shake,.22);if(Math.abs(longitudinal)>10)addWanted(1);}}
  if(hit){c.velocity.multiplyScalar(-.22);c.hp-=Math.abs(longitudinal)*.7;shake=Math.max(shake,.25);if(Math.abs(longitudinal)>12)addWanted(1);}
  c.speed=c.velocity.length()*(c.velocity.dot(f)<0?-1:1);
  c.g.rotation.y=c.yaw;
  c.wheels.forEach(w=>{w.pivot.rotation.y=w.front?steer*.42:0;w.tire.rotation.x-=longitudinal*dt*1.8;});
  if(handbrake&&Math.abs(c.speed)>7&&Math.random()<.75)spawnSmoke(c.g.position.clone().addScaledVector(f,-1.8).setY(.35),1);
  $('speedometer').classList.remove('hidden');$('speed-value').textContent=String(Math.round(Math.abs(c.speed)*3.6)).padStart(3,'0');$('gear-value').textContent=longitudinal<-.5?'R':'D';
  player.position.copy(c.g.position);player.position.y=0;
  if(c.hp<100){$('speedometer').style.borderColor='rgba(255,100,75,.65)';}else{$('speedometer').style.borderColor='';}
}

function updateTraffic(dt){
  for(const c of traffic){const a=c.ai;if(a.axis==='x')c.g.position.x+=a.sign*c.speed*dt;else c.g.position.z+=a.sign*c.speed*dt;
    if(a.axis==='x'&&Math.abs(c.g.position.x)>205)c.g.position.x=-Math.sign(c.g.position.x)*205;
    if(a.axis==='z'&&Math.abs(c.g.position.z)>205)c.g.position.z=-Math.sign(c.g.position.z)*205;
    // Small speed modulation to create a more organic flow.
    c.g.position.x=clamp(c.g.position.x,-210,210);c.g.position.z=clamp(c.g.position.z,-210,210);
    c.g.rotation.y=c.yaw;c.wheels.forEach(w=>w.tire.rotation.x-=c.speed*dt*1.8);
    if(inCar){const d=c.g.position.distanceTo(inCar.g.position);if(d<3.4&&Math.abs(inCar.speed)>10){c.speed*=.6;inCar.velocity.multiplyScalar(.72);addWanted(1);}}
  }
}

function updateNPCs(dt){
  for(const n of [...npcs]){
    const pos=n.g.position;let dir=new THREE.Vector3(Math.sin(n.dir),0,Math.cos(n.dir)),speed=n.speed;
    const distance=pos.distanceTo(player.position);
    if(n.police&&wanted){dir.copy(player.position).sub(pos).setY(0).normalize();speed=4.2+wanted*.85;n.g.rotation.y=Math.atan2(dir.x,dir.z);if(distance<2.2){n.attackCooldown-=dt;if(n.attackCooldown<=0){damage(7+wanted);n.attackCooldown=1.1;toast('ПОЛИЦИЯ АТАКУЕТ');}}}
    else if(n.panic>0||n.alert){n.panic=Math.max(0,n.panic-dt);dir.copy(pos).sub(player.position).setY(0).normalize();speed=3.6;n.g.rotation.y=Math.atan2(dir.x,dir.z);}
    else{
      n.phase+=dt;if(n.phase>rand(4,8)){n.phase=0;n.dir+=rand(-1.5,1.5);}if(distance<5){dir.copy(pos).sub(player.position).setY(0).normalize();speed=2.7;}
    }
    const old=pos.clone();pos.addScaledVector(dir,speed*dt);
    if(collideWorld(pos,.42)){n.dir+=Math.PI*rand(.4,1.1);pos.copy(old);}
    n.g.rotation.y=lerp(n.g.rotation.y,Math.atan2(dir.x,dir.z),1-Math.exp(-5*dt));
    const swing=Math.sin(performance.now()*.009+n.phase)*Math.min(.5,speed*.09);n.arms[0].rotation.x=swing;n.arms[1].rotation.x=-swing;
    if(!n.police&&distance<1.3&&inCar&&Math.abs(inCar.speed)>9){n.panic=5;n.alert=true;}
  }
  if(wanted){wantedTimer+=dt;if(player.position.distanceTo(lastKnown)>48)wantedTimer+=dt*1.35;if(wantedTimer>36){wanted=Math.max(0,wanted-1);wantedTimer=0;if(wanted===0)clearWanted();else updateWantedUI();}}
  else if(policeUnits.length)clearWanted();
}

function updateMission(dt){
  const m=missionTargets[missionIndex%missionTargets.length];markerGroup.rotation.y+=dt*.55;markerGroup.children.forEach((child,i)=>{if(i===1)child.material.opacity=.09+Math.sin(performance.now()*.002)*.035;});markerGroup.position.y=Math.sin(performance.now()*.002)*.15;
  const d=Math.hypot(player.position.x-m.x,player.position.z-m.z);$('mission-progress').style.width=clamp(100*(1-d/220),0,100)+'%';
  if(d<7){cash+=m.reward;missionIndex++;setMission();updateHUD();toast(`ЗАДАНИЕ ВЫПОЛНЕНО  +$${m.reward.toLocaleString('en-US')}`);}
}

function updateCamera(dt){
  const target=inCar?inCar.g.position:player.position;
  const speed=inCar?Math.abs(inCar.speed):Math.hypot(velocity.x,velocity.z);
  const fov=66+clamp(speed/40,0,1)*8;camera.fov=lerp(camera.fov,fov,dt*2.5);camera.updateProjectionMatrix();
  const dir=new THREE.Vector3(Math.sin(yaw)*Math.cos(pitch),Math.sin(pitch),Math.cos(yaw)*Math.cos(pitch));
  const distance=inCar?10.8:7.6,height=inCar?4.5:3.15;
  const desired=target.clone().add(new THREE.Vector3(0,height,0)).addScaledVector(dir,-distance);
  desired.y=Math.max(1.35,desired.y);
  camera.position.lerp(desired,1-Math.exp((inCar?4.2:6.5)*-dt));
  if(shake>0){camera.position.x+=rand(-shake,shake);camera.position.y+=rand(-shake,shake);shake=Math.max(0,shake-dt*.8);}
  camera.lookAt(target.x,target.y+(inCar?1.35:1.45),target.z);
}

function updateLighting(dt){
  worldTime=(worldTime+dt*.035)%24;const hour=worldTime;
  const daylight=clamp((Math.sin((hour-6)/12*Math.PI)+.16)/1.16,0,1);
  const night=1-daylight;
  const skyDay=new THREE.Color(0x8fb8d1),skyDusk=new THREE.Color(0xe29a69),skyNight=new THREE.Color(0x091323);
  let dusk=clamp(1-Math.abs(hour-18)/2.7,0,1)+clamp(1-Math.abs(hour-6)/2.7,0,1);dusk=clamp(dusk,0,1);
  const targetSky=skyNight.clone().lerp(skyDay,daylight).lerp(skyDusk,dusk*.48);
  scene.background.lerp(targetSky,1-Math.exp(-dt*.8));scene.fog.color.copy(scene.background);
  sun.intensity=.16+daylight*2.8;sun.color.copy(new THREE.Color(0xffc18a).lerp(new THREE.Color(0xfff0d7),daylight));
  sun.position.set(Math.cos((hour-12)/24*Math.PI*2)*170,Math.max(8,Math.sin((hour-6)/12*Math.PI)*170),70);
  hemi.intensity=.34+daylight*1.35;stars.material.opacity=night*.85;sunDisc.visible=daylight>.1;sunDisc.position.set(sun.position.x*.95,Math.max(10,sun.position.y),sun.position.z*.95);
  for(const m of emissiveMaterials)m.emissiveIntensity=.02+night*.68;
  for(const m of lampBulbs)m.emissiveIntensity=.05+night*2.2;
  bloom.strength=(isMobile ? 0.2 : 0.33)+night*.16;
  $('clock').textContent=String(Math.floor(hour)).padStart(2,'0')+':'+String(Math.floor((hour%1)*60)).padStart(2,'0');
}

// Audio is synthesized locally; no sound files or downloads are needed.
let audioCtx=null,engineOsc=null,engineGain=null;
function initAudio(){
  if(audioCtx)return;try{audioCtx=new (window.AudioContext||window.webkitAudioContext)();engineOsc=audioCtx.createOscillator();engineGain=audioCtx.createGain();const filter=audioCtx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=260;engineOsc.type='sawtooth';engineOsc.frequency.value=45;engineGain.gain.value=0;engineOsc.connect(filter);filter.connect(engineGain);engineGain.connect(audioCtx.destination);engineOsc.start();}catch{}
}
function updateAudio(){if(!audioCtx||!engineOsc)return;const speed=inCar?Math.abs(inCar.speed):0;engineOsc.frequency.setTargetAtTime(45+speed*3.2,audioCtx.currentTime,.08);engineGain.gain.setTargetAtTime(inCar ? 0.035 : 0,audioCtx.currentTime,.12);}
function beep(freq=660,duration=.1){if(!audioCtx)return;const osc=audioCtx.createOscillator(),gain=audioCtx.createGain();osc.frequency.value=freq;gain.gain.setValueAtTime(.06,audioCtx.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);osc.connect(gain);gain.connect(audioCtx.destination);osc.start();osc.stop(audioCtx.currentTime+duration);}

// Keyboard, pointer-lock mouse and mobile touch controls.
addEventListener('keydown',e=>{
  keys[e.code]=true;
  if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();
  if(e.code==='Escape'&&started&&!dead){paused=!paused;$('pause-screen').classList.toggle('hidden',!paused);if(paused)document.exitPointerLock?.();else if(!isMobile)renderer.domElement.requestPointerLock?.();}
  if(e.code==='KeyM'&&started&&!paused){$('map-screen').classList.remove('hidden');paused=true;drawMap($('bigmap'),true);document.exitPointerLock?.();}
  if(e.code==='KeyF'&&started&&!paused)toggleCar();if(e.code==='KeyE'&&started&&!paused)toggleCar();
  if(e.code==='KeyR'&&started&&!paused)toast('ТЕКУЩАЯ ЦЕЛЬ ОТМЕЧЕНА НА КАРТЕ');
});
addEventListener('keyup',e=>{keys[e.code]=false;});
renderer.domElement.addEventListener('click',()=>{if(started&&!paused&&!dead&&!isMobile&&$('map-screen').classList.contains('hidden'))renderer.domElement.requestPointerLock?.();});
addEventListener('mousemove',e=>{if(document.pointerLockElement===renderer.domElement&&!paused){yaw-=e.movementX*.0022;pitch=clamp(pitch-e.movementY*.0017,-.68,.24);}});
addEventListener('mousedown',e=>{if(e.button===0&&started&&!paused&&!dead&&document.pointerLockElement===renderer.domElement)attack();});
renderer.domElement.addEventListener('pointerdown',e=>{if(e.pointerType==='touch'&&started&&!paused&&!dead){touchLook={id:e.pointerId,x:e.clientX,y:e.clientY};}});
renderer.domElement.addEventListener('pointermove',e=>{if(touchLook&&e.pointerId===touchLook.id){const dx=e.clientX-touchLook.x,dy=e.clientY-touchLook.y;yaw-=dx*.006;pitch=clamp(pitch-dy*.004,-.68,.24);touchLook.x=e.clientX;touchLook.y=e.clientY;}});
renderer.domElement.addEventListener('pointerup',e=>{if(touchLook&&e.pointerId===touchLook.id)touchLook=null;});

function bindHold(id,code){const el=$(id);if(!el)return;el.addEventListener('pointerdown',e=>{e.preventDefault();keys[code]=true;el.classList.add('active');});const stop=()=>{keys[code]=false;el.classList.remove('active');};el.addEventListener('pointerup',stop);el.addEventListener('pointercancel',stop);el.addEventListener('pointerleave',stop);}
bindHold('mobile-jump','Space');bindHold('mobile-run','ShiftLeft');bindHold('mobile-brake','Space');
$('mobile-attack').addEventListener('pointerdown',e=>{e.preventDefault();attack();});
$('mobile-car').addEventListener('pointerdown',e=>{e.preventDefault();toggleCar();});
$('mobile-look').addEventListener('pointerdown',e=>{e.preventDefault();toast('Проводи пальцем по свободной части экрана, чтобы вращать камеру');});
const joy=$('joystick'),stick=$('stick');
function updateJoy(e){const rect=joy.getBoundingClientRect(),cx=rect.left+rect.width/2,cy=rect.top+rect.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const max=rect.width*.34,d=Math.hypot(dx,dy);if(d>max){dx=dx/d*max;dy=dy/d*max;}joystick.x=dx/max;joystick.y=dy/max;stick.style.transform=`translate(${dx}px,${dy}px)`;}
joy.addEventListener('pointerdown',e=>{e.preventDefault();joystick.active=true;joy.setPointerCapture(e.pointerId);updateJoy(e);});
joy.addEventListener('pointermove',e=>{if(joystick.active)updateJoy(e);});
const stopJoy=()=>{joystick.active=false;joystick.x=0;joystick.y=0;stick.style.transform='translate(0,0)';};joy.addEventListener('pointerup',stopJoy);joy.addEventListener('pointercancel',stopJoy);

// Start, pause, save and load.
$('start').onclick=()=>{started=true;paused=false;$('start-screen').classList.add('hidden');$('loading').classList.add('hidden');initAudio();audioCtx?.resume?.();if(!isMobile)renderer.domElement.requestPointerLock?.();toast('ДОБРО ПОЖАЛОВАТЬ В PACIFIC DISTRICT');beep(740,.15);};
$('resume').onclick=()=>{paused=false;$('pause-screen').classList.add('hidden');if(!isMobile)renderer.domElement.requestPointerLock?.();};
const currentSaveState=()=>({player:(inCar?inCar.g.position:player.position).toArray(),cash,health,armor,stamina,missionIndex,worldTime});
const saveNow=({quiet=false}={})=>{const result=saveGame(currentSaveState());if(result.ok){if(!quiet)toast('ИГРА СОХРАНЕНА');return true;}if(!quiet)toast('НЕ УДАЛОСЬ СОХРАНИТЬ — ПРОВЕРЬ ПАМЯТЬ БРАУЗЕРА');return false;};
$('save').onclick=()=>{if(saveNow())beep(820,.13);};
$('export-save').onclick=()=>{try{exportSave(currentSaveState());toast('ФАЙЛ СОХРАНЕНИЯ ЭКСПОРТИРОВАН');}catch(error){console.warn(error);toast('ОШИБКА ЭКСПОРТА СОХРАНЕНИЯ');}};
$('import-save').onclick=()=> $('save-file').click();
$('save-file').addEventListener('change',async event=>{const file=event.target.files?.[0];if(!file)return;try{await importSaveFile(file);toast('СОХРАНЕНИЕ ИМПОРТИРОВАНО — ПЕРЕЗАПУСК');setTimeout(()=>location.reload(),650);}catch(error){toast(error.message||'НЕ УДАЛОСЬ ИМПОРТИРОВАТЬ ФАЙЛ');}finally{event.target.value='';}});
$('new-game').onclick=()=>{clearSave();location.reload();};
$('respawn').onclick=respawn;
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>{$('map-screen').classList.add('hidden');paused=false;if(!isMobile)renderer.domElement.requestPointerLock?.();});
const savedState=loadGame();
if(savedState){player.position.fromArray(savedState.player);cash=savedState.cash;health=savedState.health;armor=savedState.armor;stamina=savedState.stamina;missionIndex=savedState.missionIndex;worldTime=savedState.worldTime;setMission();$('start').textContent='ПРОДОЛЖИТЬ ИГРУ  →';}
let autosaveElapsed=0;
updateHUD();updateWantedUI();

// Main loop.
const clock=new THREE.Clock();let mapTimer=0;
function animate(){
  requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);
  player.userData.animationMixer?.update(dt);for(const npc of npcs)npc.animationMixer?.update(dt);
  if(started&&!paused&&!dead){
    autosaveElapsed+=dt;if(autosaveElapsed>=45){saveNow({quiet:true});autosaveElapsed=0;}
    if(inCar){updatePlayerCar(dt);}else{updatePlayer(dt);$('speedometer').classList.add('hidden');}
    updateTraffic(dt);updateNPCs(dt);updateMission(dt);updateCamera(dt);updateLighting(dt);updateAudio();
    const near=nearestCar();$('vehicle-hint').classList.toggle('show',!inCar&&!!near);$('vehicle-hint').textContent=near?'НАЖМИ F — СЕСТЬ В АВТОМОБИЛЬ':'НАЙДИ ТРАНСПОРТ';
    mapTimer+=dt;if(mapTimer>.16){drawMap($('minimap'));mapTimer=0;}
  } else if(!started){updateLighting(dt*.35);}
  for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.life-=dt;p.mesh.position.addScaledVector(p.velocity,dt);p.mesh.scale.multiplyScalar(1+dt*.6);p.mesh.material.opacity=Math.max(0,p.life/p.max*.22);if(p.life<=0){scene.remove(p.mesh);p.mesh.geometry.dispose();p.mesh.material.dispose();particles.splice(i,1);}}
  composer.render();
}
animate();
addEventListener('resize',()=>{
  camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);composer.setSize(innerWidth,innerHeight);
  renderer.setPixelRatio(Math.min(devicePixelRatio||1,isMobile?1.25:1.7));
});

// Hide loading screen after the procedural world has been assembled.
requestAnimationFrame(()=>setTimeout(()=>$('loading').classList.add('hidden'),500));
