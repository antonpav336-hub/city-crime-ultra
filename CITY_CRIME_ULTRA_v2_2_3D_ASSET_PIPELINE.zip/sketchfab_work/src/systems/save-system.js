const SAVE_KEY = 'cityCrimeUltraSave';
const SAVE_VERSION = 2;

function isFiniteNumber(value) { return typeof value === 'number' && Number.isFinite(value); }

export function createSaveSnapshot(state) {
  return {
    version: SAVE_VERSION,
    savedAt: new Date().toISOString(),
    player: Array.isArray(state.player) && state.player.length === 3 && state.player.every(isFiniteNumber)
      ? state.player : [-10, 0, -3],
    cash: isFiniteNumber(state.cash) ? Math.max(0, Math.floor(state.cash)) : 2500,
    health: isFiniteNumber(state.health) ? Math.max(0, Math.min(100, state.health)) : 100,
    armor: isFiniteNumber(state.armor) ? Math.max(0, Math.min(100, state.armor)) : 25,
    stamina: isFiniteNumber(state.stamina) ? Math.max(0, Math.min(100, state.stamina)) : 100,
    missionIndex: isFiniteNumber(state.missionIndex) ? Math.max(0, Math.floor(state.missionIndex)) : 0,
    worldTime: isFiniteNumber(state.worldTime) ? ((state.worldTime % 24) + 24) % 24 : 15.2,
  };
}

export function saveGame(state) {
  const snapshot = createSaveSnapshot(state);
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(snapshot));
    return { ok: true, data: snapshot };
  } catch (error) {
    console.warn('[save] Could not write save data.', error);
    return { ok: false, error };
  }
}

export function loadGame() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return null;
    // Version 1 was the original unversioned save format.
    if (parsed.version == null || parsed.version === 1 || parsed.version === SAVE_VERSION) {
      return createSaveSnapshot(parsed);
    }
    console.warn(`[save] Unsupported save version: ${parsed.version}`);
    return null;
  } catch (error) {
    console.warn('[save] Could not read save data.', error);
    return null;
  }
}

export function exportSave(state) {
  const snapshot = createSaveSnapshot(state);
  const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `city-crime-save-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  return snapshot;
}

export function importSaveFile(file) {
  return new Promise((resolve, reject) => {
    if (!file || file.size > 1024 * 1024) {
      reject(new Error('Файл сохранения пустой или превышает 1 МБ.'));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.player)) {
          throw new Error('Неверный формат сохранения.');
        }
        const snapshot = createSaveSnapshot(parsed);
        localStorage.setItem(SAVE_KEY, JSON.stringify(snapshot));
        resolve(snapshot);
      } catch (error) { reject(error); }
    };
    reader.onerror = () => reject(new Error('Не удалось прочитать файл.'));
    reader.readAsText(file);
  });
}

export function clearSave() {
  try { localStorage.removeItem(SAVE_KEY); return true; }
  catch (error) { console.warn('[save] Could not clear save.', error); return false; }
}
