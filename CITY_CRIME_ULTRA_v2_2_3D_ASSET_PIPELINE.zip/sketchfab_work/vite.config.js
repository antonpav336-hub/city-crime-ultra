import { defineConfig } from 'vite';

// Relative paths keep the build compatible with GitHub Pages project URLs.
export default defineConfig({ base: './' });
