import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';

const root = resolve('public/assets');
const assets = [
  {
    path: 'vehicles/sedan.glb',
    url: 'https://toolbenchdev.com/gamedev/cc0-game-assets/low-poly-vehicles-kit/files/glb/sedan.glb',
    source: 'Toolbench Low-poly Vehicles Kit', license: 'CC0 1.0',
    page: 'https://toolbenchdev.com/gamedev/cc0-game-assets/low-poly-vehicles-kit/'
  },
  {
    path: 'vehicles/suv.glb',
    url: 'https://toolbenchdev.com/gamedev/cc0-game-assets/low-poly-vehicles-kit/files/glb/suv.glb',
    source: 'Toolbench Low-poly Vehicles Kit', license: 'CC0 1.0',
    page: 'https://toolbenchdev.com/gamedev/cc0-game-assets/low-poly-vehicles-kit/'
  },
  {
    path: 'vehicles/box-truck.glb',
    url: 'https://toolbenchdev.com/gamedev/cc0-game-assets/low-poly-vehicles-kit/files/glb/box_truck.glb',
    source: 'Toolbench Low-poly Vehicles Kit', license: 'CC0 1.0',
    page: 'https://toolbenchdev.com/gamedev/cc0-game-assets/low-poly-vehicles-kit/'
  },
  {
    path: 'characters/casual-walker.glb',
    url: 'https://tevy.dev/models/casual-walker/v1/lod2.glb',
    source: 'Tevy — Casual Walker LOD2', license: 'CC0 1.0',
    page: 'https://tevy.dev/models/casual-walker'
  },
  {
    path: 'buildings/bank.glb',
    url: 'https://raw.githubusercontent.com/kayquer/kit-cidade-lowpoly/main/models/comercial/banco.glb',
    source: 'Kayquer — Low Poly City Kit', license: 'CC0 1.0',
    page: 'https://github.com/kayquer/kit-cidade-lowpoly'
  },
  {
    path: 'buildings/house.glb',
    url: 'https://raw.githubusercontent.com/kayquer/kit-cidade-lowpoly/main/models/residencial/casa_simples.glb',
    source: 'Kayquer — Low Poly City Kit', license: 'CC0 1.0',
    page: 'https://github.com/kayquer/kit-cidade-lowpoly'
  },
  {
    path: 'buildings/hotel.glb',
    url: 'https://raw.githubusercontent.com/kayquer/kit-cidade-lowpoly/main/models/comercial/hotel.glb',
    source: 'Kayquer — Low Poly City Kit', license: 'CC0 1.0',
    page: 'https://github.com/kayquer/kit-cidade-lowpoly'
  }
];

await mkdir(root, { recursive: true });
const results = [];
for (const asset of assets) {
  const destination = resolve(root, asset.path);
  await mkdir(dirname(destination), { recursive: true });
  try {
    const response = await fetch(asset.url, { redirect: 'follow' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const bytes = Buffer.from(await response.arrayBuffer());
    if (bytes.length < 128 || bytes.subarray(0, 4).toString() !== 'glTF') {
      throw new Error('The response is not a valid binary GLB file');
    }
    await writeFile(destination, bytes);
    results.push({ ...asset, sizeBytes: bytes.length, status: 'downloaded' });
    console.log(`Downloaded ${asset.path} (${Math.round(bytes.length / 1024)} KB)`);
  } catch (error) {
    results.push({ ...asset, status: 'failed', error: error.message });
    console.error(`Could not download ${asset.path}: ${error.message}`);
  }
}
await writeFile(resolve(root, 'ASSET-CATALOG.json'), JSON.stringify({ version: 2, assets: results }, null, 2));
const failed = results.filter((item) => item.status !== 'downloaded');
console.log(`\n${results.length - failed.length}/${results.length} assets downloaded.`);
if (failed.length) process.exitCode = 1;
