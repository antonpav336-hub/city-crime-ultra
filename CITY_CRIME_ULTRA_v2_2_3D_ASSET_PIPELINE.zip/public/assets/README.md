# 3D assets for CITY CRIME

Run `npm run assets:download` from the project root to fetch the selected GLB files into this folder. The downloader checks the GLB magic header and writes `ASSET-CATALOG.json` with source and license metadata.

## Selected sources and licenses

- Toolbench Low-poly Vehicles Kit — sedan, SUV and box truck. CC0 1.0. https://toolbenchdev.com/gamedev/cc0-game-assets/low-poly-vehicles-kit/
- Tevy Casual Walker LOD2 — rigged pedestrian with idle/walk animations. CC0 1.0. https://tevy.dev/models/casual-walker
- Kayquer Low Poly City Kit — bank, small house and hotel. CC0 1.0. https://github.com/kayquer/kit-cidade-lowpoly

The GLB files are optional. If a download is unavailable or a model fails to load, CITY CRIME keeps its procedural vehicle/character geometry. The city buildings remain procedural in this integration pass; the downloaded building models are staged for the next pass.
